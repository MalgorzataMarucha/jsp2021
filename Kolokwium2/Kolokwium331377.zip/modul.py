def convert(key):
    klucz=key[0:4]+"-"+key[4:8]+"-"+key[8:12]+"-"+key[12:16]
    return klucz
